package com.picpay.cadocvalidator.core.exceptions;

public final class ParserException extends RuntimeException {
  public ParserException(String message) {
    super(message);
  }
}
