package com.picpay.cadocvalidator.core.validators;

import com.picpay.cadocvalidator.core.domain.Gar;
import org.springframework.stereotype.Component;

import javax.xml.stream.events.XMLEvent;

import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.TP;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.VLR_ORIG;

@Component
public final class GarValidator extends AbstractValidator implements IValidator<Gar> {
  @Override
  public Gar accept(XMLEvent event) {
    this.event = event;

    final var gar = new Gar();
    gar.setTp(validateTp());
    gar.setVlrOrig(validateVlrOrig());

    return gar;
  }

  private String validateTp() {
    final var tp = getAttribute(TP);
    return tp.getValue();
  }

  private String validateVlrOrig() {
    final var vlrOrig = getAttribute(VLR_ORIG);
    return vlrOrig.getValue();
  }
}
