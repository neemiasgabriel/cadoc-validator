package com.picpay.cadocvalidator.core.parser;

import com.picpay.cadocvalidator.core.domain.Cli;
import com.picpay.cadocvalidator.core.domain.Doc3040;
import com.picpay.cadocvalidator.core.domain.Gar;
import com.picpay.cadocvalidator.core.domain.Op;
import com.picpay.cadocvalidator.core.domain.Venc;
import com.picpay.cadocvalidator.core.domain.XmlHeader;

import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

public interface IElementVisitor {
  XmlHeader visitXmlHeader(final XMLEvent element);
  Doc3040 visitDoc3040(final StartElement element);
  Cli visitCli(final XMLEvent cliEvent);
  Op visitOp(final XMLEvent opEvent);
  Venc visitVenc(final XMLEvent vencEvent);
  Gar visitGar(final XMLEvent garEvent);
}
