package com.picpay.cadocvalidator.core.validators;

import javax.xml.stream.events.XMLEvent;

public interface IValidator<T> {
  T accept(final XMLEvent event);
}
