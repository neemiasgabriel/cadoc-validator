package com.picpay.cadocvalidator.core.parser;

import com.picpay.cadocvalidator.core.domain.Cli;
import com.picpay.cadocvalidator.core.domain.Doc3040;
import com.picpay.cadocvalidator.core.domain.Gar;
import com.picpay.cadocvalidator.core.domain.Op;
import com.picpay.cadocvalidator.core.domain.Venc;
import com.picpay.cadocvalidator.core.domain.XmlHeader;
import com.picpay.cadocvalidator.core.validators.CliValidator;
import com.picpay.cadocvalidator.core.validators.Doc3040Validator;
import com.picpay.cadocvalidator.core.validators.GarValidator;
import com.picpay.cadocvalidator.core.validators.OpValidator;
import com.picpay.cadocvalidator.core.validators.VencValidator;
import com.picpay.cadocvalidator.core.validators.XmlHeaderValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

@Component
@RequiredArgsConstructor
public final class ElementVisitor implements IElementVisitor {
  private final XmlHeaderValidator xmlHeaderValidator;
  private final Doc3040Validator doc3040Validator;
  private final CliValidator cliValidator;
  private final OpValidator opValidator;
  private final VencValidator vencValidator;
  private final GarValidator garValidator;

  @Override
  public XmlHeader visitXmlHeader(final XMLEvent element) {
    return xmlHeaderValidator.accept(element);
  }

  @Override
  public Doc3040 visitDoc3040(final StartElement element) {
    return doc3040Validator.accept(element);
  }

  @Override
  public Cli visitCli(final XMLEvent cliEvent) {
    return cliValidator.accept(cliEvent);
  }

  @Override
  public Op visitOp(final XMLEvent opEvent) {
    return opValidator.accept(opEvent);
  }

  @Override
  public Venc visitVenc(final XMLEvent vencEvent) {
    return vencValidator.accept(vencEvent);
  }

  @Override
  public Gar visitGar(final XMLEvent garEvent) {
    return garValidator.accept(garEvent);
  }
}
