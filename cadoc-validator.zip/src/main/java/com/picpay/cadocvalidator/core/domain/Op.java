package com.picpay.cadocvalidator.core.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public final class Op extends Tag {
  private String ipoc;
  private String contrt;
  private String natuOp;
  private String mod;
  private String cosif;
  private String origemRec;
  private String indx;
  private String percIndx;
  private String varCamb;
  private String dtVencOp;
  private String classOp;
  private String cep;
  private String taxEft;
  private String dtContr;
  private String provConstTd;
  private String vlrContr;
  private String dtaProxParcela;
  private String vlrProxParcela;
  private String qtdParcelas;
  private Venc venc;
  private Gar gar;
}
