package com.picpay.cadocvalidator.core.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public final class XmlHeader extends Tag {
  private String version;
  private String encoding;
}
