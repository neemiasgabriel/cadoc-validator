package com.picpay.cadocvalidator.core.parser;

import javax.xml.stream.events.XMLEvent;
import java.util.Stack;

public class XmlStack extends Stack<XMLEvent> {

}
