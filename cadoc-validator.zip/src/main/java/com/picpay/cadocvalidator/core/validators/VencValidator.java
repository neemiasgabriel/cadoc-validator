package com.picpay.cadocvalidator.core.validators;

import com.picpay.cadocvalidator.core.domain.Venc;
import org.springframework.stereotype.Component;

import javax.xml.stream.events.XMLEvent;

import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.V110;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.V120;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.V130;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.V140;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.V150;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.V160;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.V165;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.V170;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.V175;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.V180;

@Component
public final class VencValidator extends AbstractValidator implements IValidator<Venc> {
  @Override
  public Venc accept(XMLEvent event) {
    this.event = event;

    final var venc = new Venc();
    venc.setV110(validateV110());
    venc.setV120(validateV120());
    venc.setV130(validateV130());
    venc.setV140(validateV140());
    venc.setV140(validateV150());
    venc.setV160(validateV160());
    venc.setV165(validateV165());
    venc.setV170(validateV170());
    venc.setV175(validateV175());
    venc.setV180(validateV180());

    return venc;
  }

  private String validateV110() {
    final var v110 = getAttribute(V110);
    return v110 == null ? null : v110.getValue();
  }

  private String validateV120() {
    final var v120 = getAttribute(V120);
    return v120 == null ? null : v120.getValue();
  }

  private String validateV130() {
    final var v130 = getAttribute(V130);
    return v130 == null ? null : v130.getValue();
  }

  private String validateV140() {
    final var v140 = getAttribute(V140);
    return v140 == null ? null : v140.getValue();
  }

  private String validateV150() {
    final var v150 = getAttribute(V150);
    return v150 == null ? null : v150.getValue();
  }

  private String validateV160() {
    final var v160 = getAttribute(V160);
    return v160 == null ? null : v160.getValue();
  }

  private String validateV165() {
    final var v165 = getAttribute(V165);
    return v165 == null ? null : v165.getValue();
  }

  private String validateV170() {
    final var v170 = getAttribute(V170);
    return v170 == null ? null : v170.getValue();
  }

  private String validateV175() {
    final var v175 = getAttribute(V175);
    return v175 == null ? null : v175.getValue();
  }

  private String validateV180() {
    final var v180 = getAttribute(V180);
    return v180 == null ? null : v180.getValue();
  }
}
