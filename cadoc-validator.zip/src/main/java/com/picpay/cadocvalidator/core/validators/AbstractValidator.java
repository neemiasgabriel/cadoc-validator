package com.picpay.cadocvalidator.core.validators;

import com.picpay.cadocvalidator.core.dsl.enums.TokenType3040;

import javax.xml.namespace.QName;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.XMLEvent;

public abstract class AbstractValidator {
  protected XMLEvent event;

  public Attribute getAttribute(final TokenType3040 attribute) {
    return event.asStartElement().getAttributeByName(new QName(attribute.key()));
  }
}
