package com.picpay.cadocvalidator.core.validators;

import com.picpay.cadocvalidator.core.domain.Doc3040;
import com.picpay.cadocvalidator.core.exceptions.ParserException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import javax.xml.stream.events.StartElement;

import java.util.regex.Pattern;

import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.CNPJ;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.DT_BASE;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.EMAIL_RESP;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.NOME_RESP;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.PARTE;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.REMESSA;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.TEL_RESP;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.TOTAL_CLI;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.TP_ARQ;
import static com.picpay.cadocvalidator.core.validators.DataRegex.*;

@Component
@RequiredArgsConstructor
public final class Doc3040Validator extends AbstractStartValidator implements IStartValidator<Doc3040> {
  private final DateValidator dateValidator;

  @Override
  public Doc3040 accept(final StartElement startElement) {
    this.element = startElement;

    final var doc3040 = new Doc3040();
    doc3040.setDtBase(validateDtBase());
    doc3040.setCnpj(validateCnpj());
    doc3040.setRemessa(validateRemessa());
    doc3040.setParte(validateParte());
    doc3040.setTpArq(validateTpArq());
    doc3040.setNomeResp(validateNomeResp());
    doc3040.setEmailResp(validateEmailResp());
//    doc3040.setTelResp(validateTelResp());
    doc3040.setTotalCli(validateTotalCli());

    return doc3040;
  }

  private String validateDtBase() {
    final var dtBase = getAttribute(DT_BASE);
    final var value = dtBase.getValue();

    if (!dateValidator.isYearMonth(value)) {
      throw new ParserException("O DtBase da tag Doc3040 é inválido");
    }

    return value;
  }

  private String validateCnpj() {
    final var cnpj = getAttribute(CNPJ);

    if (cnpj == null) {
      throw new ParserException("O CNPJ da tag Doc3040 não pode ser nulo");
    }


    if (!Pattern.matches(CNPJ_REGEX, cnpj.getValue())) {
      throw new ParserException("O CNPJ da tag Doc3040 é inválido");
    }

    return cnpj.getValue();
  }

  private String validateRemessa() {
    final var remessa = getAttribute(REMESSA);

    if (remessa == null) {
      throw new ParserException("O atributo Remessa, da tag Doc3040, não pode ser nulo");
    }

    return remessa.getValue();
  }

  private String validateParte() {
    final var parte = getAttribute(PARTE);

    if (parte == null) {
      throw new ParserException("O atributo Parte, da tag Doc3040, não pode ser nulo");
    }

    final var value = parte.getValue();

    if (!value.equals("1")) {
      throw new ParserException("O atributo Parte, da tag Doc3040, deve ser 1");
    }

    return parte.getValue();
  }

  // Arquivo é enviado de forma fracionada
  private String validateTpArq() {
    final var tpArq = getAttribute(TP_ARQ);

    if (tpArq == null) {
      throw new ParserException("O atributo TpArq, da tag Doc3040, não pode ser nulo");
    }

    final var value = tpArq.getValue();

    if (!value.equals("F")) {
      throw new ParserException("O atributo TpArq, da tag Doc3040, deve ser enviado de forma fracionada. Atribua o valor F ao atributo");
    }

    return tpArq.getValue();
  }

  private String validateNomeResp() {
    final var nomeResp = getAttribute(NOME_RESP);

    if (nomeResp == null) {
      throw new ParserException("O atributo NomeResp, da tag Doc3040, não pode ser nulo");
    }

    return nomeResp.getValue();
  }

  private String validateEmailResp() {
    final var emailResp = getAttribute(EMAIL_RESP);

    if (emailResp == null) {
      throw new ParserException("O atributo EmailResp, da tag Doc3040, não pode ser nulo");
    }

    return emailResp.getValue();
  }

  private String validateTelResp() {
    final var telResp = getAttribute(TEL_RESP);

    if (telResp == null) {
      throw new ParserException("O atributo TelResp, da tag Doc3040, não pode ser nulo");
    }

    final var value = telResp.getValue();

    if (!Pattern.matches(TEL_REGEX, value)) {
      throw new ParserException("O atributo TelResp não segue as diretivas do Bacen");
    }

    return value;
  }

  private String validateTotalCli() {
    final var totalCli = getAttribute(TOTAL_CLI);

    if (totalCli == null) {
      throw new ParserException("O atributo TotalCli, da tag Doc3040, não pode ser nulo");
    }

    final var value = totalCli.getValue();

    try {
      Long.parseLong(value);
    } catch (NumberFormatException e) {
      throw new ParserException("O atributo TotalCli, da tag Doc3040, não é um número");
    }

    return value;
  }
}
