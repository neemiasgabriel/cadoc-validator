package com.picpay.cadocvalidator.core.validators;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DataRegex {
  public static final String CNPJ_REGEX = "^\\d{8}$";
  public static final String CPF_REGEX = "^\\d{11}$";
  public static final String TEL_REGEX = "^\\d{10}$";
}
