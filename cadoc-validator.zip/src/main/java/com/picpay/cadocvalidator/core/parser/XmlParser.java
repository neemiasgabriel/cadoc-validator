package com.picpay.cadocvalidator.core.parser;

import com.picpay.cadocvalidator.core.domain.Cli;
import com.picpay.cadocvalidator.core.domain.Doc3040;
import com.picpay.cadocvalidator.core.domain.Tag;
import com.picpay.cadocvalidator.core.domain.Gar;
import com.picpay.cadocvalidator.core.domain.Op;
import com.picpay.cadocvalidator.core.domain.Venc;
import com.picpay.cadocvalidator.core.exceptions.ParserException;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Stack;
import java.util.concurrent.TimeUnit;

@Component
@RequiredArgsConstructor
public final class XmlParser {
  private static final String DOC_3040 = "Doc3040";
  private static final String CLI = "Cli";
  private static final String OP = "Op";
  private static final String VENC = "Venc";
  private static final String GAR = "Gar";

  private final IElementVisitor elementVisitor;

  @Scheduled(fixedDelay = 1, timeUnit = TimeUnit.HOURS)
  public void processFile() {
    final var resource = new ClassPathResource("Exemplo3040.xml");
    final var xmlInputFactory = XMLInputFactory.newInstance();

    try {
      final var reader = xmlInputFactory.createXMLEventReader(new FileInputStream(resource.getFile()));

      if (!reader.hasNext()) return;

      // A pilha funciona como validador de expressão
      // É esperado que as tags estejam dentro da sequência: Doc3040 -> Cli -> Op -> Venc/Gar
      // Ao remover um item da pilha, a validação deve verificar se, ao desempilhar os elementos, a estrutura permanece válida
      // Caso contrário, uma falha deve ser lançada
      final var stack = new Stack<Tag>();

      XMLEvent nextEvent;
      Doc3040 doc3040;
      Cli cli;
      Op op;
      long line = 1;

      while (reader.hasNext()) {
        nextEvent = reader.nextEvent();

        if (nextEvent.isStartElement()) {
          final var startElement = nextEvent.asStartElement();
          final var tagName = startElement.getName().getLocalPart();

          switch (tagName) {
            case DOC_3040:
              beginTagMessage(tagName);
              doc3040 = elementVisitor.visitDoc3040(startElement);
              stack.push(doc3040);
              break;
            case CLI:
              beginTagMessage(tagName);
              cli = elementVisitor.visitCli(nextEvent);
              stack.push(cli);
              break;
            case OP:
              beginTagMessage(tagName);
              op = elementVisitor.visitOp(nextEvent);
              stack.push(op);
              break;
            case VENC:
              beginTagMessage(tagName);
              final var venc = elementVisitor.visitVenc(nextEvent);
              stack.push(venc);
              break;
            case GAR:
              beginTagMessage(tagName);
              final var gar = elementVisitor.visitGar(nextEvent);
              stack.push(gar);
              break;
            default:
              ignoredTag(tagName);
          }
        } else if (nextEvent.isEndElement()) {
          final var endElement = nextEvent.asEndElement();
          final var tagName = endElement.getName().getLocalPart();

          switch (tagName) {
            case DOC_3040:
              final var docExpr = stack.pop();

              if (docExpr instanceof Doc3040) {
                endTagMessage(tagName);
              }
              break;
            case CLI:
              final var cliExp = stack.pop();

              if (cliExp instanceof Cli) {
                endTagMessage(tagName);
              }
              break;
            case OP:
              setOp(stack);
              break;
            default:
              System.out.println("Tag Pulada: " + tagName);
          }
        }

        line++;
      }

      System.out.println("Fim do processamento");
    } catch (FileNotFoundException e) {
      throw new RuntimeException(e);
    } catch (XMLStreamException e) {
      throw new RuntimeException(e);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  private String message(final String tagName) {
    return "Tag " + tagName + " esperada. Porém, não encontrada nesse ponto do arquivo";
  }

  private void beginTagMessage(final String tagName) { System.out.println("Tag Aberta: " + tagName); }

  private void endTagMessage(final String tagName) {
    System.out.println("Tag Fechada: " + tagName);
  }

  private void ignoredTag(final String tagName) {
    System.out.println("Tag ignorada: " + tagName);
  }

  private void ignoredEndTag(final String tagName) {
    System.out.println("Tag ignorada at the end: " + tagName);
  }

  private void setOp(final Stack<Tag> stack) {
    final var tag1 = stack.pop();
    final var tag2 = stack.pop();
    var tag3 = stack.peek();

    if (tag2 instanceof Op opTag) {
      if (tag1 instanceof Venc vencTag) {
        opTag.setVenc(vencTag);
        setOpToCli(opTag, tag3, stack);
        endTagMessage("Op");
      } else if (tag1 instanceof Gar garTag) {
        opTag.setGar(garTag);
        setOpToCli(opTag, tag3, stack);
        endTagMessage("Op");
      } else {
        throw new ParserException("A tag esperado não é essa");
      }
    } else if (tag3 instanceof Op opTag) {
      opTag = (Op) stack.pop();

      if (tag1 instanceof Venc vencTag) {
        opTag.setVenc(vencTag);
      } else if (tag1 instanceof Gar garTag) {
        opTag.setGar(garTag);
      } else {
        throw new ParserException("A tag esperado não é essa");
      }

      if (tag2 instanceof Venc vencTag) {
        opTag.setVenc(vencTag);
      } else if (tag2 instanceof Gar garTag) {
        opTag.setGar(garTag);
      } else {
        throw new ParserException("A tag esperado não é essa");
      }

      var tag4 = stack.peek();

      setOpToCli(opTag, tag4, stack);
      endTagMessage("Op");
    }
  }

  private void setOpToCli(final Op opTag, final Tag tag, final Stack<Tag> stack) {
    if (tag instanceof Cli) {
      final var cliTag = (Cli) stack.pop();
      cliTag.getOps().add(opTag);
      stack.push(cliTag);
    } else {
      throw new ParserException("A tag esperado não é essa");
    }
  }
}
