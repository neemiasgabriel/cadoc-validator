package com.picpay.cadocvalidator.core.validators;

import javax.xml.stream.events.StartElement;

public interface IStartValidator<T> {
  T accept(final StartElement event);
}
