package com.picpay.cadocvalidator.core.validators;

import com.picpay.cadocvalidator.core.domain.XmlHeader;
import com.picpay.cadocvalidator.core.dsl.enums.TokenType3040;
import org.springframework.stereotype.Component;

import javax.xml.namespace.QName;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.XMLEvent;

import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.ENCODING;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.VERSION;

@Component
public final class XmlHeaderValidator extends AbstractValidator implements IValidator<XmlHeader> {
  @Override
  public XmlHeader accept(final XMLEvent event) {
    this.event = event;

    final var header = new XmlHeader();
    header.setEncoding(validateEncoding());
    header.setVersion(validateVersion());

    return header;
  }

  private String validateEncoding() {
    final var encoding = this.getAttribute(ENCODING);
    return encoding.getValue();
  }

  private String validateVersion() {
    final var version = this.getAttribute(VERSION);
    return version.getValue();
  }

  @Override
  public Attribute getAttribute(final TokenType3040 attribute) {
    return event.asStartElement().getAttributeByName(new QName(attribute.key()));
  }
}
