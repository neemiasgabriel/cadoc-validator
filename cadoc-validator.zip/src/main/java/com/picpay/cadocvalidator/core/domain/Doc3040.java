package com.picpay.cadocvalidator.core.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public final class Doc3040 extends Tag {
  private String dtBase;
  private String cnpj;
  private String remessa;
  private String parte;
  private String tpArq;
  private String nomeResp;
  private String emailResp;
  private String telResp;
  private String totalCli;
  private List<Cli> clis = new ArrayList<>();
}
