package com.picpay.cadocvalidator.core.validators;

import com.picpay.cadocvalidator.core.domain.Cli;
import com.picpay.cadocvalidator.core.exceptions.ParserException;
import org.springframework.stereotype.Component;

import javax.xml.stream.events.XMLEvent;

import java.util.regex.Pattern;

import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.AUTORZC;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.CD;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.CLASS_CLI;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.FAT_ANUAL;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.INI_RELACT_CLI;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.PORTE_CLI;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.TP;
import static com.picpay.cadocvalidator.core.validators.DataRegex.CNPJ_REGEX;
import static com.picpay.cadocvalidator.core.validators.DataRegex.CPF_REGEX;

@Component
public final class CliValidator extends AbstractValidator implements IValidator<Cli> {
  @Override
  public Cli accept(final XMLEvent event) {
    this.event = event;

    final var cli = new Cli();
    cli.setTp(validateTp());
    cli.setCd(validateCd(cli.getTp()));
    cli.setAutorzc(validateAutorzc());
    cli.setPorteCli(validatePorteCli());
    cli.setIniRelactCli(validateIniRelactCli());
    cli.setFatAnual(validateFatAnual());
    cli.setClassCli(validateClassCli());

    return cli;
  }

  // TP = Tipo Pessoa
  private String validateTp() {
    final var tp = getAttribute(TP);

    if (tp == null) {
      throw new ParserException("O Tp, da tag Cli, não pode ser nulo");
    }

    final var value = tp.getValue();

    try {
      final var longValue = Long.parseLong(value);

      if (!(longValue > 0 && longValue <= 6)) {
        throw new ParserException("O código do Tp, da tag Cli, deve ser estar no intervalo de 1 à 6");
      }
    } catch (NumberFormatException e) {
      throw new ParserException("O código do Tp, da tag Cli, não é um número");
    }

    return value;
  }

  // CD = Código do Cliente (CPF/CNPJ)
  private String validateCd(final String tp) {
    final var tpValue = Integer.parseInt(tp);
    final var cd = getAttribute(CD);

    final var result = switch (tpValue) {
      case 1 -> Pattern.matches(CPF_REGEX, cd.getValue());
      case 2 -> Pattern.matches(CNPJ_REGEX, cd.getValue());
      default -> cd.getValue().length() == 14;
    };

    if (!result) {
      throw new ParserException("O atributo Cd, da tag Cli, é inválido");
    }

    return cd.getValue();
  }

  private String validateAutorzc() {
    final var autorzc = getAttribute(AUTORZC);

    if (autorzc == null) {
      throw new ParserException("O atributo autorzc, da tag Cli, não pode ser nulo");
    }

    final var value = autorzc.getValue();

    if (!(value.equals("S") || value.equals("N"))) {
      throw new ParserException("O atributo Autorzc, da tag Cli, é inválido");
    }

    return autorzc.getValue();
  }

  private String validatePorteCli() {
    final var porteCli = getAttribute(PORTE_CLI);

    if (porteCli == null) {
      throw new ParserException("O atributo PorteCli, da tag Cli, não pode ser nulo");
    }


    return porteCli.getValue();
  }

  private String validateIniRelactCli() {
    final var iniRelactCli = getAttribute(INI_RELACT_CLI);

    if (iniRelactCli == null) {
      throw new ParserException("O atributo InitRelactCli, da tag Cli, não pode ser nulo");
    }

    return iniRelactCli.getValue();
  }

  private String validateFatAnual() {
    final var fatAnual = getAttribute(FAT_ANUAL);

    if (fatAnual == null) {
      throw new ParserException("O atributo FatAnual, da tag Cli, não pode ser nulo");
    }

    return fatAnual.getValue();
  }

  private String validateClassCli() {
    final var classCli = getAttribute(CLASS_CLI);

    if (classCli == null) {
      throw new ParserException("O atributo ClassCli, da tag Cli, não pode ser nulo");
    }

    return classCli.getValue();
  }
}
