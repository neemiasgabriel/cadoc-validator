package com.picpay.cadocvalidator.core.domain;

import com.google.gson.Gson;

public abstract class Tag {
  public String toJson() {
    return new Gson().toJson(this);
  }
}
