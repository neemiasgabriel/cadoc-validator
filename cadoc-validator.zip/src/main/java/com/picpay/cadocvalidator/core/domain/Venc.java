package com.picpay.cadocvalidator.core.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public final class Venc extends Tag {
  private String v110;
  private String v120;
  private String v130;
  private String v140;
  private String v150;
  private String v160;
  private String v165;
  private String v170;
  private String v175;
  private String v180;
}
