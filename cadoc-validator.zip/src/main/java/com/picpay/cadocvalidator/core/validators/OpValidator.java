package com.picpay.cadocvalidator.core.validators;

import com.picpay.cadocvalidator.core.domain.Op;
import org.springframework.stereotype.Component;

import javax.xml.stream.events.XMLEvent;

import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.CEP;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.CLASS_OP;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.CONTRT;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.COSIF;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.DTA_PROX_PARCELA;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.DT_CONTR;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.DT_VENC_OP;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.INDX;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.IPOC;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.MOD;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.NATU_OP;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.ORIGEM_REC;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.PERC_INDX;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.PROV_CONSTTD;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.QTD_PARCELAS;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.TAX_EFT;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.VAR_CAMB;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.VLR_CONTR;
import static com.picpay.cadocvalidator.core.dsl.enums.TokenType3040.VLR_PROX_PARCELA;

@Component
public final class OpValidator extends AbstractValidator implements IValidator<Op> {
  @Override
  public Op accept(final XMLEvent event) {
    this.event = event;

    final var op = new Op();
    op.setIpoc(validateIpoc());
    op.setContrt(validateContrt());
    op.setNatuOp(validateNatuOp());
    op.setMod(validateMod());
    op.setCosif(validateCosif());
    op.setOrigemRec(validateOrigemRec());
    op.setIndx(validateIndx());
    op.setPercIndx(validatePercIndx());
    op.setVarCamb(validateVarCamb());
    op.setDtVencOp(validateDtVencOp());
    op.setClassOp(validateClassOp());
    op.setCep(validateCep());
    op.setTaxEft(validateTaxEft());
    op.setDtContr(validateDtContr());
    op.setProvConstTd(validateProvConstTd());
    op.setVlrContr(validateVlrContr());
    op.setDtaProxParcela(validateDtaProxParcela());
    op.setVlrProxParcela(validateVlrProxParcela());
    op.setQtdParcelas(validateQtdParcelas());

    return op;
  }

  private String validateIpoc() {
    final var attr = getAttribute(IPOC);
    return attr.getValue();
  }
  private String validateContrt() {
    final var attr = getAttribute(CONTRT);
    return attr.getValue();
  }
  private String validateNatuOp() {
    final var attr = getAttribute(NATU_OP);
    return attr.getValue();
  }
  private String validateMod() {
    final var attr = getAttribute(MOD);
    return attr.getValue();
  }
  private String validateCosif() {
    final var attr = getAttribute(COSIF);
    return attr.getValue();
  }
  private String validateOrigemRec() {
    final var attr = getAttribute(ORIGEM_REC);
    return attr.getValue();
  }
  private String validateIndx() {
    final var attr = getAttribute(INDX);
    return attr.getValue();
  }
  private String validatePercIndx() {
    final var attr = getAttribute(PERC_INDX);
    return attr.getValue();
  }
  private String validateVarCamb() {
    final var attr = getAttribute(VAR_CAMB);
    return attr.getValue();
  }
  private String validateDtVencOp() {
    final var attr = getAttribute(DT_VENC_OP);
    return attr.getValue();
  }
  private String validateClassOp() {
    final var attr = getAttribute(CLASS_OP);
    return attr.getValue();
  }
  private String validateCep() {
    final var attr = getAttribute(CEP);
    return attr.getValue();
  }
  private String validateTaxEft() {
    final var attr = getAttribute(TAX_EFT);
    return attr.getValue();
  }
  private String validateDtContr() {
    final var attr = getAttribute(DT_CONTR);
    return attr.getValue();
  }
  private String validateProvConstTd() {
    final var attr = getAttribute(PROV_CONSTTD);
    return attr.getValue();
  }
  private String validateVlrContr() {
    final var attr = getAttribute(VLR_CONTR);
    return attr.getValue();
  }
  private String validateDtaProxParcela() {
    final var attr = getAttribute(DTA_PROX_PARCELA);
    return attr.getValue();
  }
  private String validateVlrProxParcela() {
    final var attr = getAttribute(VLR_PROX_PARCELA);
    return attr.getValue();
  }
  private String validateQtdParcelas() {
    final var attr = getAttribute(QTD_PARCELAS);
    return attr.getValue();
  }
}
