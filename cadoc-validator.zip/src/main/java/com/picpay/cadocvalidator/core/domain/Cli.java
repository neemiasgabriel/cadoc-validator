package com.picpay.cadocvalidator.core.domain;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public final class Cli extends Tag {
  private String tp;
  private String cd;
  private String autorzc;
  private String porteCli;
  private String iniRelactCli;
  private String fatAnual;
  private String classCli;
  private List<Op> ops = new ArrayList<>();
}
