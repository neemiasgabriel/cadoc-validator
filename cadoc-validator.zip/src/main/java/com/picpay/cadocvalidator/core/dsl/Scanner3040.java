package com.picpay.cadocvalidator.core.dsl;

import org.springframework.stereotype.Component;

@Component
public final class Scanner3040 {

}
